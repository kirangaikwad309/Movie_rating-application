import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { DashboardComponent } from './dashboard/dashboard.component';
import { ExploreComponent } from './explore/explore.component';

import { HomeComponent } from './home';
import { SettingsComponent } from './settings/settings.component';
import { ShowmoviesComponent } from './showmovies/showmovies.component';
import { AuthGuard } from './_helpers';

const accountModule = () => import('./account/account.module').then(x => x.AccountModule);
const usersModule = () => import('./users/users.module').then(x => x.UsersModule);

const routes: Routes = [
    { path: '', component: HomeComponent, canActivate: [AuthGuard] },
    { path:'dashboard',component:DashboardComponent,canActivate: [AuthGuard] },
    {path:'explore',component:ExploreComponent,canActivate: [AuthGuard] },
    { path:'settings',component:SettingsComponent,canActivate: [AuthGuard] },
    {path:'view/:id',component:ShowmoviesComponent },
    { path: 'users', loadChildren: usersModule, canActivate: [AuthGuard] },
    { path: 'account', loadChildren: accountModule },

    // otherwise redirect to home
    { path: '**', redirectTo: '' },
    
];

@NgModule({
    imports: [RouterModule.forRoot(routes, { relativeLinkResolution: 'legacy' })],
    exports: [RouterModule]
})
export class AppRoutingModule { }