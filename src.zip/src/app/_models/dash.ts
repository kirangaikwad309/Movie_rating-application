export interface Dash{

Title:string,
Year:number,
imdbID:string,
Type:string
}