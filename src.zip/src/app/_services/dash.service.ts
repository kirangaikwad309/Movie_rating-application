import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Dash } from '@app/_models/dash';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class DashService {

  constructor(private httpClient:HttpClient) { }

  
  private apiUrl="http://www.omdbapi.com/?s=one&page=1&apikey=yourApiKey";

  public getProduct=():Observable<Dash[]>=>{
    return this.httpClient.get<Dash[]>(this.apiUrl);
  }
  public getProductByID=(id:number):Observable<Dash>=>{
    return this.httpClient.get<Dash>(`${this.apiUrl}/${id}`);
  }
}
