import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-showmovies',
  templateUrl: './showmovies.component.html',
  styleUrls: ['./showmovies.component.less']
})
export class ShowmoviesComponent implements OnInit {
  lis:any;
  constructor(private route: Router,private acet:ActivatedRoute,private http : HttpClient) { }

  ngOnInit(): void {
    let id=this.acet.snapshot.params['id'];
    console.log("id"+id)
    console.log('http://www.omdbapi.com/?apikey=54e3123d&i='+id)
    this.http.get('http://www.omdbapi.com/?apikey=54e3123d&i='+id) 
    .subscribe((Response:any) => { 
 console.log(JSON.stringify(Response))
 this.lis=Response
 console.log("xyz"+this.lis[0].Title);
      if(Response){   
        this.lis=Response
        console.log("xyz"+this.lis[0].Title);
       
      } 
     }); 
  }

}
