import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Dash } from '@app/_models/dash';
import { DashService } from '@app/_services/dash.service';
import { Pipe, PipeTransform } from '@angular/core';
@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.less']
})
export class DashboardComponent implements OnInit {
  li:any; 
  lis=[]; 
  items = [];
  pageOfItems: Array<any>;
  constructor(private router:Router,private http : HttpClient) { }
  ngOnInit(): void { 
    
    this.http.get('http://www.omdbapi.com/?s=one&page=1&apikey=54e3123d') 
    .subscribe((Response:any) => { 
 
      if(Response){   
        this.lis=Response.Search
        console.log(this.lis);
       
      } 
     }); 
    }
  
    view(id)
    {
      console.log("this is id"+id)
    this.router.navigate(['view',id]);
    
    }
}
